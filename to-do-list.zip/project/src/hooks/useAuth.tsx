import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { User, AuthState, LoginCredentials, SignupCredentials } from '../types/auth';
import { 
  hashPassword, 
  verifyPassword, 
  generateUserId, 
  validateEmail, 
  validatePassword,
  generateTwoFactorSecret,
  verifyTwoFactorCode,
  storeUser,
  getUserByEmail
} from '../utils/authUtils';

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<{ success: boolean; error?: string; requiresTwoFactor?: boolean }>;
  signup: (credentials: SignupCredentials) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  enableTwoFactor: () => Promise<{ secret: string; qrCode: string }>;
  confirmTwoFactor: (code: string) => Promise<{ success: boolean; error?: string }>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true
  });

  useEffect(() => {
    // Check for existing session
    const storedUser = localStorage.getItem('taskflow_current_user');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        setAuthState({
          user: { ...user, createdAt: new Date(user.createdAt) },
          isAuthenticated: true,
          isLoading: false
        });
      } catch {
        localStorage.removeItem('taskflow_current_user');
        setAuthState(prev => ({ ...prev, isLoading: false }));
      }
    } else {
      setAuthState(prev => ({ ...prev, isLoading: false }));
    }
  }, []);

  const login = async (credentials: LoginCredentials) => {
    const { email, password, twoFactorCode } = credentials;
    
    if (!validateEmail(email)) {
      return { success: false, error: 'Invalid email format' };
    }

    const userData = getUserByEmail(email);
    if (!userData) {
      return { success: false, error: 'Invalid email or password' };
    }

    if (!verifyPassword(password, userData.passwordHash)) {
      return { success: false, error: 'Invalid email or password' };
    }

    // Check if 2FA is enabled
    if (userData.twoFactorEnabled) {
      if (!twoFactorCode) {
        return { success: false, requiresTwoFactor: true };
      }

      if (!userData.twoFactorSecret || !verifyTwoFactorCode(userData.twoFactorSecret, twoFactorCode)) {
        return { success: false, error: 'Invalid two-factor authentication code' };
      }
    }

    const user: User = {
      id: userData.id,
      email: userData.email,
      name: userData.name,
      createdAt: userData.createdAt,
      twoFactorEnabled: userData.twoFactorEnabled,
      twoFactorSecret: userData.twoFactorSecret
    };

    setAuthState({
      user,
      isAuthenticated: true,
      isLoading: false
    });

    localStorage.setItem('taskflow_current_user', JSON.stringify(user));
    return { success: true };
  };

  const signup = async (credentials: SignupCredentials) => {
    const { name, email, password, confirmPassword } = credentials;

    if (!name.trim()) {
      return { success: false, error: 'Name is required' };
    }

    if (!validateEmail(email)) {
      return { success: false, error: 'Invalid email format' };
    }

    const passwordValidation = validatePassword(password);
    if (!passwordValidation.isValid) {
      return { success: false, error: passwordValidation.errors[0] };
    }

    if (password !== confirmPassword) {
      return { success: false, error: 'Passwords do not match' };
    }

    // Check if user already exists
    if (getUserByEmail(email)) {
      return { success: false, error: 'An account with this email already exists' };
    }

    const user: User = {
      id: generateUserId(),
      email,
      name: name.trim(),
      createdAt: new Date(),
      twoFactorEnabled: false
    };

    const passwordHash = hashPassword(password);
    storeUser(user, passwordHash);

    setAuthState({
      user,
      isAuthenticated: true,
      isLoading: false
    });

    localStorage.setItem('taskflow_current_user', JSON.stringify(user));
    return { success: true };
  };

  const logout = () => {
    setAuthState({
      user: null,
      isAuthenticated: false,
      isLoading: false
    });
    localStorage.removeItem('taskflow_current_user');
  };

  const enableTwoFactor = async () => {
    if (!authState.user) {
      throw new Error('User not authenticated');
    }

    const secret = generateTwoFactorSecret();
    const qrCode = `otpauth://totp/TaskFlow:${authState.user.email}?secret=${secret}&issuer=TaskFlow`;
    
    return { secret, qrCode };
  };

  const confirmTwoFactor = async (code: string) => {
    if (!authState.user) {
      return { success: false, error: 'User not authenticated' };
    }

    const userData = getUserByEmail(authState.user.email);
    if (!userData) {
      return { success: false, error: 'User not found' };
    }

    // Get the temporary secret from the enable process
    const tempSecret = sessionStorage.getItem('temp_2fa_secret');
    if (!tempSecret) {
      return { success: false, error: 'Two-factor setup session expired' };
    }

    if (!verifyTwoFactorCode(tempSecret, code)) {
      return { success: false, error: 'Invalid verification code' };
    }

    // Update user with 2FA enabled
    const updatedUser: User = {
      ...authState.user,
      twoFactorEnabled: true,
      twoFactorSecret: tempSecret
    };

    storeUser(updatedUser, userData.passwordHash);
    setAuthState(prev => ({ ...prev, user: updatedUser }));
    localStorage.setItem('taskflow_current_user', JSON.stringify(updatedUser));
    sessionStorage.removeItem('temp_2fa_secret');

    return { success: true };
  };

  return (
    <AuthContext.Provider value={{
      ...authState,
      login,
      signup,
      logout,
      enableTwoFactor,
      confirmTwoFactor
    }}>
      {children}
    </AuthContext.Provider>
  );
}