export interface Todo {
  id: string;
  text: string;
  completed: boolean;
  createdAt: Date;
  priority: 'low' | 'medium' | 'high';
}

export interface TodoStats {
  total: number;
  completed: number;
  pending: number;
  completionRate: number;
}