import React, { useState } from 'react';
import { User, Shield, LogOut, Settings } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { TwoFactorSetup } from './auth/TwoFactorSetup';

export function UserProfile() {
  const { user, logout } = useAuth();
  const [showTwoFactorSetup, setShowTwoFactorSetup] = useState(false);

  if (!user) return null;

  return (
    <>
      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-full">
              <User className="text-white" size={24} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800">{user.name}</h2>
              <p className="text-gray-600">{user.email}</p>
              <div className="flex items-center gap-2 mt-1">
                <Shield size={16} className={user.twoFactorEnabled ? 'text-green-600' : 'text-gray-400'} />
                <span className={`text-sm ${user.twoFactorEnabled ? 'text-green-600' : 'text-gray-500'}`}>
                  2FA {user.twoFactorEnabled ? 'Enabled' : 'Disabled'}
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {!user.twoFactorEnabled && (
              <button
                onClick={() => setShowTwoFactorSetup(true)}
                className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-700 rounded-lg hover:bg-green-100 transition-colors"
              >
                <Shield size={16} />
                Enable 2FA
              </button>
            )}
            
            <button
              onClick={logout}
              className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors"
            >
              <LogOut size={16} />
              Sign Out
            </button>
          </div>
        </div>
      </div>

      {showTwoFactorSetup && (
        <TwoFactorSetup
          onComplete={() => setShowTwoFactorSetup(false)}
          onCancel={() => setShowTwoFactorSetup(false)}
        />
      )}
    </>
  );
}