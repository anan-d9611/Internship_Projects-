import { User } from '../types/auth';
import * as OTPAuth from 'otpauth';

// Simulate password hashing (in production, use proper bcrypt)
export function hashPassword(password: string): string {
  // This is a simple hash for demo purposes - use proper bcrypt in production
  return btoa(password + 'salt123');
}

export function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export function generateUserId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePassword(password: string): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }
  
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  
  if (!/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// 2FA Utils
export function generateTwoFactorSecret(): string {
  return new OTPAuth.Secret().base32;
}

export function generateTwoFactorQR(email: string, secret: string): string {
  const totp = new OTPAuth.TOTP({
    issuer: 'TaskFlow',
    label: email,
    algorithm: 'SHA1',
    digits: 6,
    period: 30,
    secret: OTPAuth.Secret.fromBase32(secret),
  });
  
  return totp.toString();
}

export function verifyTwoFactorCode(secret: string, token: string): boolean {
  const totp = new OTPAuth.TOTP({
    issuer: 'TaskFlow',
    algorithm: 'SHA1',
    digits: 6,
    period: 30,
    secret: OTPAuth.Secret.fromBase32(secret),
  });
  
  const delta = totp.validate({ token, window: 1 });
  return delta !== null;
}

// Storage utilities
export function getStoredUsers(): Record<string, any> {
  try {
    const users = localStorage.getItem('taskflow_users');
    return users ? JSON.parse(users) : {};
  } catch {
    return {};
  }
}

export function storeUser(user: User, passwordHash: string): void {
  const users = getStoredUsers();
  users[user.email] = {
    ...user,
    passwordHash,
    createdAt: user.createdAt.toISOString()
  };
  localStorage.setItem('taskflow_users', JSON.stringify(users));
}

export function getUserByEmail(email: string): (User & { passwordHash: string }) | null {
  const users = getStoredUsers();
  const userData = users[email];
  
  if (!userData) return null;
  
  return {
    ...userData,
    createdAt: new Date(userData.createdAt)
  };
}