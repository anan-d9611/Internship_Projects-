# Expense Tracker

A beautiful, production-ready expense tracking web application built with React, TypeScript, and Tailwind CSS. This comprehensive financial management tool helps users track their income and expenses with advanced features like data visualization, filtering, and data import/export capabilities.

## 🌟 Features

### Core Functionality
- **Transaction Management**: Add, edit, and delete income and expense transactions
- **Smart Categorization**: Predefined categories for both income and expenses
- **Real-time Calculations**: Automatic calculation of total income, expenses, and net balance
- **Data Persistence**: Automatic saving to local storage
- **Input Validation**: Comprehensive form validation with error messages

### Advanced Features
- **Interactive Filtering**: Filter by transaction type, category, and search by description
- **Data Visualization**: Beautiful pie chart showing expense breakdown by category
- **Data Management**: Export transactions to JSON and import existing data
- **Transaction Editing**: Edit existing transactions with pre-filled forms
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices

### User Experience
- **Modern UI**: Clean, professional design with smooth animations
- **Real-time Updates**: Instant updates to summaries and charts
- **Confirmation Dialogs**: Safety confirmations for destructive actions
- **Intuitive Navigation**: Easy-to-use interface with clear visual hierarchy

## 🚀 Getting Started

### Prerequisites
- Node.js (version 14 or higher)
- npm or yarn package manager

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd expense-tracker
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to the provided local server URL (typically `http://localhost:5173`)

## 📱 Usage Guide

### Adding Transactions
1. Select transaction type (Income or Expense)
2. Fill in the description, amount, date, and category
3. Click "Add Transaction" to save

### Managing Transactions
- **Edit**: Click the edit icon on any transaction to modify it
- **Delete**: Click the trash icon to remove a transaction
- **Filter**: Use the filter section to find specific transactions

### Data Management
- **Export**: Download your transaction data as a JSON file
- **Import**: Upload a previously exported JSON file to restore data
- **Clear All**: Remove all transactions (with confirmation)

### Understanding the Dashboard
- **Green Card**: Total income earned
- **Red Card**: Total expenses spent
- **Blue/Orange Card**: Net balance (profit/loss)
- **Pie Chart**: Visual breakdown of expenses by category

## 🏗️ Code Structure

```
src/
├── components/           # React components
│   ├── TransactionForm.tsx    # Add/edit transaction form
│   ├── TransactionList.tsx    # List of transactions
│   ├── Summary.tsx           # Financial summary cards
│   ├── CategoryFilter.tsx    # Filtering controls
│   ├── PieChart.tsx         # Expense visualization
│   └── DataControls.tsx     # Import/export controls
├── utils/               # Utility functions
│   ├── storage.ts           # Local storage operations
│   └── calculations.ts      # Financial calculations
├── types.ts            # TypeScript type definitions
├── App.tsx             # Main application component
└── main.tsx            # Application entry point
```

## 🛠️ Technologies Used

- **React 18**: Modern React with hooks and functional components
- **TypeScript**: Type-safe JavaScript for better development experience
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Beautiful, customizable icons
- **Vite**: Fast build tool and development server

## 💾 Data Storage

The application uses browser local storage to persist data. This means:
- Your data is stored locally on your device
- Data persists between browser sessions
- No data is sent to external servers
- You can export your data for backup purposes

## 🎨 Design Philosophy

The application follows modern design principles:
- **Clean and Minimal**: Focused on essential features without clutter
- **Consistent Visual Language**: Uniform spacing, colors, and typography
- **Responsive First**: Designed to work perfectly on all screen sizes
- **Accessible**: Proper contrast ratios and keyboard navigation support
- **Professional**: Suitable for both personal and business use

## 📊 Financial Categories

### Income Categories
- Salary
- Freelance
- Investment
- Business
- Gift
- Other

### Expense Categories
- Food & Dining
- Transportation
- Entertainment
- Shopping
- Healthcare
- Utilities
- Education
- Travel
- Other

## 🔧 Customization

The application is built with modularity in mind. You can easily:
- Add new transaction categories by modifying `src/types.ts`
- Customize colors and styling in the component files
- Add new chart types or visualizations
- Extend the data export formats

## 📈 Future Enhancements

Potential features for future versions:
- Monthly/yearly budget tracking
- Recurring transaction support
- Multiple account management
- Advanced reporting and analytics
- Mobile app version
- Cloud synchronization
- Receipt photo attachment

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues or pull requests to improve the application.

## 📄 License

This project is open source and available under the MIT License.

---

**Note**: This is a client-side application that stores data locally. For production use with multiple users, consider implementing a backend API for data storage and user authentication.