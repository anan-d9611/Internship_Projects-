import React, { useState, useEffect, useMemo } from 'react';
import { TrendingUp, BarChart3 } from 'lucide-react';
import { AuthWrapper } from './components/AuthWrapper';
import { UserProfile } from './components/UserProfile';
import { TransactionForm } from './components/TransactionForm';
import { TransactionList } from './components/TransactionList';
import { Summary } from './components/Summary';
import { CategoryFilter } from './components/CategoryFilter';
import { PieChart } from './components/PieChart';
import { DataControls } from './components/DataControls';
import { Transaction, User } from './types';
import { calculateSummary, getCategoryData } from './utils/calculations';
import { saveTransactions, loadTransactions, exportTransactions } from './utils/storage';

interface AppProps {
  user?: User;
  onLogout?: () => void;
}

function AppContent({ user, onLogout }: AppProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | undefined>();
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedType, setSelectedType] = useState<'all' | 'income' | 'expense'>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Load transactions from localStorage on mount
  useEffect(() => {
    if (user) {
      const savedTransactions = loadTransactions(user.id);
      setTransactions(savedTransactions);
    }
  }, [user]);

  // Save transactions to localStorage whenever transactions change
  useEffect(() => {
    if (user && transactions.length >= 0) {
      saveTransactions(transactions, user.id);
    }
  }, [transactions, user]);

  const addTransaction = (transactionData: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTransaction: Transaction = {
      ...transactionData,
      id: crypto.randomUUID(),
      createdAt: Date.now()
    };
    setTransactions(prev => [newTransaction, ...prev]);
  };

  const updateTransaction = (updatedTransaction: Transaction) => {
    setTransactions(prev =>
      prev.map(t => t.id === updatedTransaction.id ? updatedTransaction : t)
    );
    setEditingTransaction(undefined);
  };

  const deleteTransaction = (id: string) => {
    if (window.confirm('Are you sure you want to delete this transaction?')) {
      setTransactions(prev => prev.filter(t => t.id !== id));
    }
  };

  const handleEditTransaction = (transaction: Transaction) => {
    setEditingTransaction(transaction);
  };

  const handleCancelEdit = () => {
    setEditingTransaction(undefined);
  };

  const handleExport = () => {
    exportTransactions(transactions, user?.name);
  };

  const handleImport = (importedTransactions: Transaction[]) => {
    // Merge with existing transactions, avoiding duplicates by ID
    const existingIds = new Set(transactions.map(t => t.id));
    const newTransactions = importedTransactions.filter(t => !existingIds.has(t.id));
    
    if (newTransactions.length > 0) {
      setTransactions(prev => [...newTransactions, ...prev]);
      alert(`Successfully imported ${newTransactions.length} new transactions.`);
    } else {
      alert('No new transactions to import.');
    }
  };

  const handleClearAll = () => {
    setTransactions([]);
  };

  // Filter transactions based on selected filters
  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      const matchesCategory = selectedCategory === '' || transaction.category === selectedCategory;
      const matchesType = selectedType === 'all' || transaction.type === selectedType;
      const matchesSearch = searchTerm === '' || 
        transaction.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      return matchesCategory && matchesType && matchesSearch;
    });
  }, [transactions, selectedCategory, selectedType, searchTerm]);

  const summary = useMemo(() => calculateSummary(transactions), [transactions]);
  const categoryData = useMemo(() => getCategoryData(transactions), [transactions]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-2xl">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Expense Tracker</h1>
                <p className="text-gray-600">Manage your finances with ease</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="hidden sm:flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-xl">
                <BarChart3 size={18} className="text-gray-600" />
                <span className="text-sm text-gray-600 font-medium">
                  {transactions.length} transactions
                </span>
              </div>
              
              {user && onLogout && (
                <UserProfile user={user} onLogout={onLogout} />
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Message */}
        {user && (
          <div className="mb-8 p-6 bg-gradient-to-r from-emerald-500 to-blue-600 rounded-2xl text-white">
            <h2 className="text-2xl font-bold mb-2">Welcome back, {user.name}!</h2>
            <p className="text-emerald-100">Ready to track your expenses and achieve your financial goals?</p>
          </div>
        )}

        {/* Summary Cards */}
        <Summary summary={summary} />

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="xl:col-span-2 space-y-8">
            {/* Transaction Form */}
            <TransactionForm
              onAddTransaction={addTransaction}
              editingTransaction={editingTransaction}
              onUpdateTransaction={updateTransaction}
              onCancelEdit={handleCancelEdit}
            />

            {/* Filters */}
            <CategoryFilter
              selectedCategory={selectedCategory}
              selectedType={selectedType}
              onCategoryChange={setSelectedCategory}
              onTypeChange={setSelectedType}
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
            />

            {/* Transaction List */}
            <TransactionList
              transactions={filteredTransactions}
              onDeleteTransaction={deleteTransaction}
              onEditTransaction={handleEditTransaction}
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Pie Chart */}
            <PieChart data={categoryData} />

            {/* Data Controls */}
            <DataControls
              transactions={transactions}
              onExport={handleExport}
              onImport={handleImport}
              onClearAll={handleClearAll}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-50 border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-gray-600">
              Built with React, TypeScript, and Tailwind CSS
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Keep track of your expenses and achieve your financial goals
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <AuthWrapper>
      <AppContent />
    </AuthWrapper>
  );
}

export default App;