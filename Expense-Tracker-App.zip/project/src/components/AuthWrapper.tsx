import React, { useState, useEffect } from 'react';
import { LoginForm } from './LoginForm';
import { TwoFactorForm } from './TwoFactorForm';
import { User } from '../types';
import { 
  authenticateUser, 
  verifyTwoFactor, 
  registerUser, 
  saveAuthState, 
  getAuthState, 
  clearAuthState,
  findUserByEmail 
} from '../utils/auth';

interface AuthWrapperProps {
  children: React.ReactNode;
}

export const AuthWrapper: React.FC<AuthWrapperProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [requiresTwoFactor, setRequiresTwoFactor] = useState(false);
  const [tempUserId, setTempUserId] = useState<string>('');
  const [error, setError] = useState('');
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    // Check if user is already authenticated
    const authState = getAuthState();
    if (authState.isAuthenticated && authState.user) {
      setUser(authState.user);
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = async (email: string, password: string) => {
    setIsLoading(true);
    setError('');
    setUserEmail(email);

    try {
      const result = await authenticateUser(email, password);
      
      if (result.success && result.user) {
        // Direct login success
        setUser(result.user);
        setIsAuthenticated(true);
        saveAuthState({
          user: result.user,
          isAuthenticated: true,
          requiresTwoFactor: false
        });
      } else if (result.requiresTwoFactor && result.tempUserId) {
        // 2FA required
        setRequiresTwoFactor(true);
        setTempUserId(result.tempUserId);
      } else {
        setError(result.message || 'Login failed');
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (email: string, password: string, name: string) => {
    setIsLoading(true);
    setError('');
    setUserEmail(email);

    try {
      const result = await registerUser(email, password, name);
      
      if (result.success && result.user) {
        if (result.user.twoFactorEnabled) {
          // 2FA required for new user
          setRequiresTwoFactor(true);
          setTempUserId(result.user.id);
        } else {
          // Direct registration success
          setUser(result.user);
          setIsAuthenticated(true);
          saveAuthState({
            user: result.user,
            isAuthenticated: true,
            requiresTwoFactor: false
          });
        }
      } else {
        setError(result.message || 'Registration failed');
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTwoFactorVerify = async (code: string) => {
    setIsLoading(true);
    setError('');

    try {
      const result = await verifyTwoFactor(tempUserId, code);
      
      if (result.success && result.user) {
        setUser(result.user);
        setIsAuthenticated(true);
        setRequiresTwoFactor(false);
        saveAuthState({
          user: result.user,
          isAuthenticated: true,
          requiresTwoFactor: false
        });
      } else {
        setError(result.message || 'Verification failed');
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTwoFactorBack = () => {
    setRequiresTwoFactor(false);
    setTempUserId('');
    setError('');
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setRequiresTwoFactor(false);
    setTempUserId('');
    setError('');
    clearAuthState();
  };

  if (isAuthenticated && user) {
    return (
      <div>
        {React.cloneElement(children as React.ReactElement, { 
          user, 
          onLogout: handleLogout 
        })}
      </div>
    );
  }

  if (requiresTwoFactor) {
    return (
      <TwoFactorForm
        onVerify={handleTwoFactorVerify}
        onBack={handleTwoFactorBack}
        isLoading={isLoading}
        error={error}
        userEmail={userEmail}
      />
    );
  }

  return (
    <LoginForm
      onLogin={handleLogin}
      onRegister={handleRegister}
      isLoading={isLoading}
      error={error}
    />
  );
};