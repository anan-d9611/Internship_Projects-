import React from 'react';
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { Summary as SummaryType } from '../types';
import { formatCurrency } from '../utils/calculations';

interface SummaryProps {
  summary: SummaryType;
}

export const Summary: React.FC<SummaryProps> = ({ summary }) => {
  const { totalIncome, totalExpenses, netIncome } = summary;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {/* Total Income */}
      <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-white/20 rounded-xl">
            <TrendingUp size={24} />
          </div>
          <span className="text-emerald-100 text-sm font-semibold">INCOME</span>
        </div>
        <div>
          <p className="text-3xl font-bold mb-1">{formatCurrency(totalIncome)}</p>
          <p className="text-emerald-100 text-sm">Total earned</p>
        </div>
      </div>

      {/* Total Expenses */}
      <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-white/20 rounded-xl">
            <TrendingDown size={24} />
          </div>
          <span className="text-red-100 text-sm font-semibold">EXPENSES</span>
        </div>
        <div>
          <p className="text-3xl font-bold mb-1">{formatCurrency(totalExpenses)}</p>
          <p className="text-red-100 text-sm">Total spent</p>
        </div>
      </div>

      {/* Net Income */}
      <div className={`bg-gradient-to-br ${
        netIncome >= 0 
          ? 'from-blue-500 to-blue-600' 
          : 'from-orange-500 to-orange-600'
      } rounded-2xl p-6 text-white shadow-lg`}>
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 bg-white/20 rounded-xl">
            <DollarSign size={24} />
          </div>
          <span className={`${
            netIncome >= 0 ? 'text-blue-100' : 'text-orange-100'
          } text-sm font-semibold`}>
            NET {netIncome >= 0 ? 'PROFIT' : 'LOSS'}
          </span>
        </div>
        <div>
          <p className="text-3xl font-bold mb-1">{formatCurrency(Math.abs(netIncome))}</p>
          <p className={`${
            netIncome >= 0 ? 'text-blue-100' : 'text-orange-100'
          } text-sm`}>
            {netIncome >= 0 ? 'Available balance' : 'Over budget'}
          </p>
        </div>
      </div>
    </div>
  );
};