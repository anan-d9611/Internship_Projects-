import React from 'react';
import { CategoryData } from '../types';
import { formatCurrency } from '../utils/calculations';

interface PieChartProps {
  data: CategoryData[];
}

export const PieChart: React.FC<PieChartProps> = ({ data }) => {
  if (data.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Expense Breakdown</h3>
        <div className="text-center py-8">
          <p className="text-gray-500">No expense data to display</p>
        </div>
      </div>
    );
  }

  let cumulativePercentage = 0;

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      <h3 className="text-xl font-bold text-gray-800 mb-6">Expense Breakdown</h3>
      
      <div className="flex flex-col lg:flex-row items-center gap-8">
        {/* Pie Chart */}
        <div className="relative w-64 h-64 flex-shrink-0">
          <svg width="256" height="256" viewBox="0 0 256 256" className="transform -rotate-90">
            <circle
              cx="128"
              cy="128"
              r="100"
              fill="none"
              stroke="#f3f4f6"
              strokeWidth="20"
            />
            {data.map((item, index) => {
              const startAngle = (cumulativePercentage / 100) * 360;
              const endAngle = ((cumulativePercentage + item.percentage) / 100) * 360;
              cumulativePercentage += item.percentage;

              const startAngleRad = (startAngle * Math.PI) / 180;
              const endAngleRad = (endAngle * Math.PI) / 180;

              const largeArcFlag = item.percentage > 50 ? 1 : 0;

              const x1 = 128 + 100 * Math.cos(startAngleRad);
              const y1 = 128 + 100 * Math.sin(startAngleRad);
              const x2 = 128 + 100 * Math.cos(endAngleRad);
              const y2 = 128 + 100 * Math.sin(endAngleRad);

              const pathData = [
                `M 128 128`,
                `L ${x1} ${y1}`,
                `A 100 100 0 ${largeArcFlag} 1 ${x2} ${y2}`,
                'Z'
              ].join(' ');

              return (
                <path
                  key={index}
                  d={pathData}
                  fill={item.color}
                  stroke="white"
                  strokeWidth="2"
                />
              );
            })}
          </svg>
        </div>

        {/* Legend */}
        <div className="flex-1 w-full">
          <div className="space-y-3">
            {data.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div
                    className="w-4 h-4 rounded-full flex-shrink-0"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="font-medium text-gray-800">{item.category}</span>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-800">
                    {formatCurrency(item.amount)}
                  </div>
                  <div className="text-sm text-gray-500">
                    {item.percentage.toFixed(1)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};