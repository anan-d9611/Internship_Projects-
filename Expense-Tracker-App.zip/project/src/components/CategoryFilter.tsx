import React from 'react';
import { Filter, X } from 'lucide-react';
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '../types';

interface CategoryFilterProps {
  selectedCategory: string;
  selectedType: 'all' | 'income' | 'expense';
  onCategoryChange: (category: string) => void;
  onTypeChange: (type: 'all' | 'income' | 'expense') => void;
  searchTerm: string;
  onSearchChange: (term: string) => void;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  selectedCategory,
  selectedType,
  onCategoryChange,
  onTypeChange,
  searchTerm,
  onSearchChange
}) => {
  const categories = selectedType === 'income' ? INCOME_CATEGORIES : 
                    selectedType === 'expense' ? EXPENSE_CATEGORIES :
                    [...INCOME_CATEGORIES, ...EXPENSE_CATEGORIES];

  const hasActiveFilters = selectedCategory !== '' || selectedType !== 'all' || searchTerm !== '';

  const clearAllFilters = () => {
    onCategoryChange('');
    onTypeChange('all');
    onSearchChange('');
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Filter size={20} className="text-gray-600" />
          <h3 className="text-lg font-semibold text-gray-800">Filters</h3>
        </div>
        {hasActiveFilters && (
          <button
            onClick={clearAllFilters}
            className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-800 transition-colors"
          >
            <X size={16} />
            Clear all
          </button>
        )}
      </div>

      <div className="space-y-4">
        {/* Search */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Search transactions
          </label>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search by description..."
            className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:border-blue-500 transition-colors"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Transaction Type Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Transaction Type
            </label>
            <select
              value={selectedType}
              onChange={(e) => onTypeChange(e.target.value as 'all' | 'income' | 'expense')}
              className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:border-blue-500 transition-colors bg-white"
            >
              <option value="all">All Types</option>
              <option value="income">Income Only</option>
              <option value="expense">Expenses Only</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Category
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => onCategoryChange(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-xl focus:outline-none focus:border-blue-500 transition-colors bg-white"
            >
              <option value="">All Categories</option>
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};