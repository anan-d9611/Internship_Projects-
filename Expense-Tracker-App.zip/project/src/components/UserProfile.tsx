import React from 'react';
import { User, LogOut, Shield, Mail, Calendar } from 'lucide-react';
import { User as UserType } from '../types';
import { formatDate } from '../utils/calculations';

interface UserProfileProps {
  user: UserType;
  onLogout: () => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({ user, onLogout }) => {
  return (
    <div className="relative group">
      <button className="flex items-center gap-3 p-3 bg-white/80 backdrop-blur-sm rounded-xl border border-gray-200 hover:bg-white transition-colors">
        <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-full flex items-center justify-center">
          <User className="w-5 h-5 text-white" />
        </div>
        <div className="text-left hidden sm:block">
          <p className="font-semibold text-gray-800">{user.name}</p>
          <p className="text-sm text-gray-600">{user.email}</p>
        </div>
      </button>

      {/* Dropdown Menu */}
      <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-2xl shadow-xl border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
        <div className="p-6">
          {/* User Info */}
          <div className="flex items-center gap-4 mb-6 pb-6 border-b border-gray-100">
            <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-800 text-lg">{user.name}</h3>
              <p className="text-gray-600">{user.email}</p>
              {user.isVerified && (
                <div className="flex items-center gap-1 mt-1">
                  <Shield className="w-4 h-4 text-emerald-500" />
                  <span className="text-sm text-emerald-600 font-medium">Verified</span>
                </div>
              )}
            </div>
          </div>

          {/* Account Details */}
          <div className="space-y-4 mb-6">
            <div className="flex items-center gap-3 text-sm">
              <Mail className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600">Email verified</span>
              <div className="w-2 h-2 bg-emerald-500 rounded-full ml-auto"></div>
            </div>
            
            <div className="flex items-center gap-3 text-sm">
              <Shield className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600">2FA enabled</span>
              <div className="w-2 h-2 bg-emerald-500 rounded-full ml-auto"></div>
            </div>
            
            <div className="flex items-center gap-3 text-sm">
              <Calendar className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600">
                Member since {formatDate(new Date(user.createdAt).toISOString().split('T')[0])}
              </span>
            </div>
          </div>

          {/* Logout Button */}
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition-colors font-semibold"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};