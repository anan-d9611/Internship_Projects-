import React, { useRef } from 'react';
import { Download, Upload, RotateCcw } from 'lucide-react';
import { Transaction } from '../types';

interface DataControlsProps {
  transactions: Transaction[];
  onExport: () => void;
  onImport: (transactions: Transaction[]) => void;
  onClearAll: () => void;
}

export const DataControls: React.FC<DataControlsProps> = ({
  transactions,
  onExport,
  onImport,
  onClearAll
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const importedTransactions = JSON.parse(text);
      
      if (Array.isArray(importedTransactions)) {
        onImport(importedTransactions);
      } else {
        alert('Invalid file format. Please select a valid JSON file.');
      }
    } catch (error) {
      alert('Error reading file. Please make sure it\'s a valid JSON file.');
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleClearAll = () => {
    if (transactions.length === 0) return;
    
    const confirmed = window.confirm(
      'Are you sure you want to delete all transactions? This action cannot be undone.'
    );
    
    if (confirmed) {
      onClearAll();
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Data Management</h3>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Export */}
        <button
          onClick={onExport}
          disabled={transactions.length === 0}
          className="flex items-center justify-center gap-2 p-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          <Download size={18} />
          Export Data
        </button>

        {/* Import */}
        <button
          onClick={handleImportClick}
          className="flex items-center justify-center gap-2 p-3 bg-emerald-500 text-white rounded-xl hover:bg-emerald-600 transition-colors"
        >
          <Upload size={18} />
          Import Data
        </button>

        {/* Clear All */}
        <button
          onClick={handleClearAll}
          disabled={transactions.length === 0}
          className="flex items-center justify-center gap-2 p-3 bg-red-500 text-white rounded-xl hover:bg-red-600 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          <RotateCcw size={18} />
          Clear All
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept=".json"
        onChange={handleFileChange}
        className="hidden"
      />
      
      <p className="text-sm text-gray-600 mt-4">
        Export your data to backup or import existing transaction data from a JSON file.
      </p>
    </div>
  );
};