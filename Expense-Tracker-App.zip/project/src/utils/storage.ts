import { Transaction } from '../types';

const getStorageKey = (userId?: string) => {
  return userId ? `expense-tracker-transactions-${userId}` : 'expense-tracker-transactions';
};

export const saveTransactions = (transactions: Transaction[], userId?: string): void => {
  try {
    const storageKey = getStorageKey(userId);
    localStorage.setItem(storageKey, JSON.stringify(transactions));
  } catch (error) {
    console.error('Failed to save transactions:', error);
  }
};

export const loadTransactions = (userId?: string): Transaction[] => {
  try {
    const storageKey = getStorageKey(userId);
    const data = localStorage.getItem(storageKey);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Failed to load transactions:', error);
    return [];
  }
};

export const exportTransactions = (transactions: Transaction[], userName?: string): void => {
  const dataStr = JSON.stringify(transactions, null, 2);
  const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
  
  const userPrefix = userName ? `${userName.replace(/\s+/g, '-').toLowerCase()}-` : '';
  const exportFileDefaultName = `${userPrefix}expense-tracker-${new Date().toISOString().split('T')[0]}.json`;
  
  const linkElement = document.createElement('a');
  linkElement.setAttribute('href', dataUri);
  linkElement.setAttribute('download', exportFileDefaultName);
  linkElement.click();
};

export const importTransactions = (file: File): Promise<Transaction[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const transactions = JSON.parse(event.target?.result as string);
        if (Array.isArray(transactions)) {
          resolve(transactions);
        } else {
          reject(new Error('Invalid file format'));
        }
      } catch (error) {
        reject(new Error('Failed to parse file'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
};