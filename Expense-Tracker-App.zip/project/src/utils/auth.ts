import { User, AuthState } from '../types';

const AUTH_STORAGE_KEY = 'expense-tracker-auth';
const USERS_STORAGE_KEY = 'expense-tracker-users';

// Mock user database
export const saveUser = (user: User): void => {
  try {
    const users = getUsers();
    const existingIndex = users.findIndex(u => u.id === user.id);
    
    if (existingIndex >= 0) {
      users[existingIndex] = user;
    } else {
      users.push(user);
    }
    
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (error) {
    console.error('Failed to save user:', error);
  }
};

export const getUsers = (): User[] => {
  try {
    const data = localStorage.getItem(USERS_STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Failed to load users:', error);
    return [];
  }
};

export const findUserByEmail = (email: string): User | null => {
  const users = getUsers();
  return users.find(user => user.email.toLowerCase() === email.toLowerCase()) || null;
};

export const saveAuthState = (authState: Partial<AuthState>): void => {
  try {
    const currentState = getAuthState();
    const newState = { ...currentState, ...authState };
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(newState));
  } catch (error) {
    console.error('Failed to save auth state:', error);
  }
};

export const getAuthState = (): AuthState => {
  try {
    const data = localStorage.getItem(AUTH_STORAGE_KEY);
    return data ? JSON.parse(data) : {
      user: null,
      isAuthenticated: false,
      isLoading: false,
      requiresTwoFactor: false
    };
  } catch (error) {
    console.error('Failed to load auth state:', error);
    return {
      user: null,
      isAuthenticated: false,
      isLoading: false,
      requiresTwoFactor: false
    };
  }
};

export const clearAuthState = (): void => {
  try {
    localStorage.removeItem(AUTH_STORAGE_KEY);
  } catch (error) {
    console.error('Failed to clear auth state:', error);
  }
};

// Mock authentication functions
export const authenticateUser = async (email: string, password: string): Promise<{ success: boolean; user?: User; requiresTwoFactor?: boolean; tempUserId?: string; message?: string }> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const user = findUserByEmail(email);
  
  if (!user) {
    return { success: false, message: 'User not found' };
  }
  
  // In a real app, you'd verify the password hash
  // For demo purposes, we'll accept any password
  
  if (user.twoFactorEnabled) {
    return { 
      success: false, 
      requiresTwoFactor: true, 
      tempUserId: user.id,
      message: 'Two-factor authentication required' 
    };
  }
  
  return { success: true, user };
};

export const verifyTwoFactor = async (userId: string, code: string): Promise<{ success: boolean; user?: User; message?: string }> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const users = getUsers();
  const user = users.find(u => u.id === userId);
  
  if (!user) {
    return { success: false, message: 'User not found' };
  }
  
  // For demo purposes, accept '123456' as valid code
  if (code === '123456') {
    return { success: true, user };
  }
  
  return { success: false, message: 'Invalid verification code' };
};

export const registerUser = async (email: string, password: string, name: string): Promise<{ success: boolean; user?: User; message?: string }> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const existingUser = findUserByEmail(email);
  
  if (existingUser) {
    return { success: false, message: 'User already exists' };
  }
  
  const newUser: User = {
    id: crypto.randomUUID(),
    email: email.toLowerCase(),
    name,
    isVerified: true,
    twoFactorEnabled: true, // Enable 2FA by default for demo
    createdAt: Date.now()
  };
  
  saveUser(newUser);
  
  return { success: true, user: newUser };
};

export const generateTwoFactorCode = (): string => {
  // In a real app, this would be generated server-side and sent via SMS/email
  return '123456';
};