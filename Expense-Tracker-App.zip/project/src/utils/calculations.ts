import { Transaction, Summary, CategoryData } from '../types';

export const calculateSummary = (transactions: Transaction[]): Summary => {
  const totalIncome = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
  
  return {
    totalIncome,
    totalExpenses,
    netIncome: totalIncome - totalExpenses
  };
};

export const getCategoryData = (transactions: Transaction[]): CategoryData[] => {
  const expenseTransactions = transactions.filter(t => t.type === 'expense');
  const totalExpenses = expenseTransactions.reduce((sum, t) => sum + t.amount, 0);
  
  if (totalExpenses === 0) return [];
  
  const categoryMap = new Map<string, number>();
  
  expenseTransactions.forEach(transaction => {
    const current = categoryMap.get(transaction.category) || 0;
    categoryMap.set(transaction.category, current + transaction.amount);
  });
  
  const colors = [
    '#EF4444', '#F97316', '#EAB308', '#22C55E', '#06B6D4', 
    '#3B82F6', '#8B5CF6', '#EC4899', '#F43F5E'
  ];
  
  return Array.from(categoryMap.entries())
    .map(([category, amount], index) => ({
      category,
      amount,
      percentage: (amount / totalExpenses) * 100,
      color: colors[index % colors.length]
    }))
    .sort((a, b) => b.amount - a.amount);
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount);
};

export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};